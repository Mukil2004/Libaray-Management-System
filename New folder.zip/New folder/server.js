// server.js
require("dotenv").config();
const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcrypt");
const morgan = require("morgan");

const app = express();
const port = process.env.PORT || 5000;

// Ensure uploads directory exists
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

// Multer configuration
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadDir),
    filename: (req, file, cb) => {
        const uniqueName = `${Date.now()}-${file.originalname}`;
        cb(null, uniqueName);
    },
});

const fileFilter = (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png/;
    const isValidType = allowedTypes.test(file.mimetype) && allowedTypes.test(path.extname(file.originalname).toLowerCase());
    cb(isValidType ? null : new Error("Only .jpeg, .jpg, or .png files are allowed!"), isValidType);
};

const upload = multer({
    storage,
    limits: { fileSize: 2 * 1024 * 1024 },
    fileFilter,
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

// MySQL connection
const db = mysql.createConnection({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "Root@123",
    database: process.env.DB_NAME || "library_management",
    multipleStatements: true,
});

db.connect(err => {
    if (err) console.error("Database connection failed:", err.message);
    else console.log("Connected to MySQL database.");
});

// --- ROUTES ---
// User Login
app.post("/login", (req, res) => {
    const { userId, password } = req.body;

    if (!userId || !password) {
        return res.status(400).json({ success: false, message: "UserId and password are required." });
    }

    db.query("SELECT * FROM users WHERE userId = ?", [userId], async (err, results) => {
        if (err) {
            console.error("Login Query Error:", err.message);
            return res.status(500).json({ success: false, message: "Database error." });
        }

        if (results.length > 0) {
            const isMatch = await bcrypt.compare(password, results[0].password);
            return res.status(isMatch ? 200 : 401).json({
                success: isMatch,
                message: isMatch ? undefined : "Invalid credentials.",
                role: isMatch ? results[0].role : undefined
            });
        } else {
            return res.status(401).json({ success: false, message: "Invalid credentials." });
        }
    });
});

// Add New User
app.post("/add-user", upload.single("proof"), async (req, res) => {
    const { userId, password, role, phone, email } = req.body;
    const proofFile = req.file;

    if (!userId || !password || !role || !phone || !email || !proofFile) {
        return res.status(400).json({ success: false, message: "All fields including proof file are required." });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const query = "INSERT INTO users (userId, password, role, phone, email, proof_path) VALUES (?, ?, ?, ?, ?, ?)";
        db.query(query, [userId, hashedPassword, role, phone, email, proofFile.path], err => {
            if (err) {
                console.error("Add User Error:", err.message);
                return res.status(500).json({ success: false, message: "Failed to add user." });
            }
            res.json({ success: true, message: "User added successfully.", userId });
        });
    } catch (err) {
        console.error("Password Hashing Error:", err.message);
        res.status(500).json({ success: false, message: "Internal server error." });
    }
});

// Get All Books
app.get("/books", (req, res) => {
    db.query("SELECT * FROM books", (err, results) => {
        if (err) {
            console.error("Get Books Error:", err.message);
            return res.status(500).json({ success: false, message: "Failed to fetch books." });
        }
        res.json({ success: true, data: results });
    });
});

// Update Book
app.put("/books/:id", (req, res) => {
    const { id } = req.params;
    const { name, author, location, available } = req.body;

    if (!name || !author || !location || available === undefined) {
        return res.status(400).json({ success: false, message: "All fields are required." });
    }

    const query = "UPDATE books SET name = ?, author = ?, location = ?, available = ? WHERE id = ?";
    db.query(query, [name, author, location, available, id], err => {
        if (err) {
            console.error("Update Book Error:", err.message);
            return res.status(500).json({ success: false, message: "Failed to update book." });
        }
        res.json({ success: true, message: "Book updated successfully." });
    });
});

// --- ERROR HANDLING ---
app.use((req, res) => {
    res.status(404).json({ success: false, message: "Endpoint not found." });
});

app.use((err, req, res, next) => {
    console.error("Internal Server Error:", err.stack);
    res.status(500).json({ success: false, message: "Internal server error." });
});

// --- START SERVER ---
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
